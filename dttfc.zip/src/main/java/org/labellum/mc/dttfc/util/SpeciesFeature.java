package org.labellum.mc.dttfc.util;

import java.util.Random;
import com.dtteam.dynamictrees.tree.species.Species;
import com.dtteam.dynamictrees.utility.CoordUtils;
import com.dtteam.dynamictrees.api.worldgen.LevelContext;
import com.dtteam.dynamictrees.worldgen.DynamicTreeGenerationContext;
import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;

public class SpeciesFeature extends Feature<SpeciesConfig>
{
    public SpeciesFeature(Codec<SpeciesConfig> codec)
    {
        super(codec);
    }

    @Override
    public boolean place(FeaturePlaceContext<SpeciesConfig> context)
    {
        final WorldGenLevel level = context.level();
        final BlockPos pos = context.origin();
        final var rand = context.random();
        final BlockPos groundPos = pos.below();
        final BlockState dirtState = level.getBlockState(groundPos);
        final Species species = context.config().species();
        if (species.isValid())
        {
            if (species.isAcceptableSoilForWorldgen(level, groundPos, dirtState))
            {
                final var biome = level.getBiome(groundPos);
                final LevelContext levelContext = LevelContext.create(context.level());

                // noinspection removal
                return species.generate(new DynamicTreeGenerationContext(levelContext, species, pos, groundPos.mutable(), biome, CoordUtils.getRandomDir(rand), 5, true));
            }
        }

        return false;
    }
}
