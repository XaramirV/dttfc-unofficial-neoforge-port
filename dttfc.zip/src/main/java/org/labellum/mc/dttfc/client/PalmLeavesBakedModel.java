package org.labellum.mc.dttfc.client;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.function.Function;

import com.dtteam.dynamictrees.block.leaves.PalmLeavesProperties;
import com.dtteam.dynamictrees.utility.CoordUtils;
import com.google.common.primitives.Ints;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.block.model.BlockModel;
import net.minecraft.client.renderer.block.model.FaceBakery;
import net.minecraft.client.renderer.block.model.ItemOverrides;
import net.minecraft.client.renderer.block.model.ItemTransforms;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.client.resources.model.Material;
import net.minecraft.client.resources.model.SimpleBakedModel;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.client.ChunkRenderTypeSet;
import net.neoforged.neoforge.client.model.data.ModelData;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class PalmLeavesBakedModel extends BaseBakedModel
{
    protected final BlockModel blockModel;

    private final TextureAtlasSprite frondsTexture;

    private final BakedModel[] bakedFronds;

    public PalmLeavesBakedModel(ResourceLocation modelResLoc, ResourceLocation frondsResLoc, Function<Material, TextureAtlasSprite> spriteGetter)
    {
        this.blockModel = new BlockModel(null, new ArrayList<>(), new HashMap<>(), false, BlockModel.GuiLight.FRONT, ItemTransforms.NO_TRANSFORMS, new ArrayList<>());
        this.bakedFronds = new BakedModel[8];

        frondsTexture = spriteGetter.apply(new Material(TextureAtlas.LOCATION_BLOCKS, frondsResLoc));

        for (CoordUtils.Surround surr : CoordUtils.Surround.values())
        {

            SimpleBakedModel.Builder builder = new SimpleBakedModel.Builder(blockModel, ItemOverrides.EMPTY, false).particle(frondsTexture);

            BlockVertexData[] quadData = {
                new BlockVertexData(0, 0, 3, 0.9375f, 0.25f),
                new BlockVertexData(0, 1, 3, 0.9375f, 0),
                new BlockVertexData(0, 1, 0, 0, 0),
                new BlockVertexData(0, 0, 0, 0, 0.25f),
                new BlockVertexData(0, 0, 3, 0.9375f, 0.25f),
                new BlockVertexData(0, 0, 0, 0, 0.25f),
                new BlockVertexData(0, 1, 0, 0, 0),
                new BlockVertexData(0, 1, 3, 0.9375f, 0)
            };

            for (int pass = 0; pass < 4; pass++)
            {
                for (int half = 0; half < 2; half++)
                {

                    BlockVertexData[] outData = new BlockVertexData[8];

                    for (int v = 0; v < 8; v++)
                    {

                        // Nab the vertex;
                        float x = quadData[v].x;
                        float z = quadData[v].z;
                        float y = quadData[v].y;

                        x *= (40f / 32f);
                        z *= (40f / 32f);

                        double len;
                        double angle;
                        double mult;

                        // Rotate the vertex around x0,y=0.75
                        // Rotate on z axis
                        len = 0.75 - y;
                        angle = Math.atan2(x, y);
                        angle += Math.PI * (half == 1 ? 0.8 : -0.8);
                        x = (float) (Math.sin(angle) * len);
                        y = (float) (Math.cos(angle) * len);


                        // Rotate the vertex around x0,z0
                        // Rotate on x axis
                        len = Math.sqrt(y * y + z * z);
                        angle = Math.atan2(y, z);
                        switch (pass)
                        {
                            case 0:
                                mult = -0.29;
                                break;
                            case 1:
                                mult = -0.06;
                                break;
                            case 2:
                                mult = 0.16;
                                break;
                            case 3:
                                mult = 0.32;
                                break;
                            default:
                                mult = 0;
                        }
                        angle += Math.PI * mult;
                        y = (float) (Math.sin(angle) * len);
                        z = (float) (Math.cos(angle) * len);

                        // Rotate the vertex around x0,z0
                        // Rotate on y axis
                        len = Math.sqrt(x * x + z * z);
                        angle = Math.atan2(x, z);
                        switch (pass)
                        {
                            case 3:
                            case 0:
                                mult = 0.005;
                                break;
                            case 1:
                                mult = 0.185;
                                break;
                            case 2:
                                mult = 0.08;
                                break;
                            default:
                                mult = 0;
                        }
                        angle += Math.PI * 0.25 * surr.ordinal() + (Math.PI * mult);
                        x = (float) (Math.sin(angle) * len);
                        z = (float) (Math.cos(angle) * len);


                        // Move to center of block
                        x += 0.5f;
                        z += 0.5f;
                        switch (pass)
                        {
                            case 0:
                                y += 0.125;
                                break;
                            case 2:
                                y += -0.125;
                                break;
                            default:
                                y += 0;
                        }
                        //y -= 0.25f;


                        // Move to center of palm crown
                        x += surr.getOffset().getX();
                        z += surr.getOffset().getZ();


                        outData[v] = new BlockVertexData(x, y, z, quadData[v].u, quadData[v].v);
                    }

                    int[] vertices = Ints.concat(
                        outData[0].toInts(frondsTexture),
                        outData[1].toInts(frondsTexture),
                        outData[2].toInts(frondsTexture),
                        outData[3].toInts(frondsTexture)
                    );
                    builder.addUnculledFace(new BakedQuad(vertices,
                        0, FaceBakery.calculateFacing(vertices), frondsTexture, true)
                    );

                    vertices = Ints.concat(
                        outData[4].toInts(frondsTexture),
                        outData[5].toInts(frondsTexture),
                        outData[6].toInts(frondsTexture),
                        outData[7].toInts(frondsTexture)
                    );
                    builder.addUnculledFace(new BakedQuad(vertices,
                        0, FaceBakery.calculateFacing(vertices), frondsTexture, true)
                    );


                    bakedFronds[surr.ordinal()] = builder.build();

                }
            }
        }
    }

    @NotNull
    @Override
    public List<BakedQuad> getQuads(@Nullable BlockState state, @Nullable Direction side, @NotNull RandomSource rand, @NotNull ModelData extraData, @Nullable RenderType renderType)
    {
        if (state == null || side != null)
            return Collections.emptyList();

        LinkedList<BakedQuad> quads = new LinkedList<>();

        int direction = state.getValue(PalmLeavesProperties.DynamicPalmLeavesBlock.DIRECTION);

        if (direction != 0)
            quads.addAll(bakedFronds[direction - 1].getQuads(state, null, rand, extraData, renderType));


        return quads;
    }

    @Override
    public ChunkRenderTypeSet getRenderTypes(@NotNull BlockState state, @NotNull RandomSource rand, @NotNull ModelData data)
    {
        return ChunkRenderTypeSet.of(RenderType.cutoutMipped());
    }

    @Override
    public TextureAtlasSprite getParticleIcon()
    {
        return frondsTexture;
    }

    public static class BlockVertexData
    {

        public float x;
        public float y;
        public float z;
        public int color;
        public float u;
        public float v;

        public BlockVertexData(float x, float y, float z, float u, float v)
        {
            this.x = x;
            this.y = y;
            this.z = z;
            this.u = u;
            this.v = v;
            color = 0xFFFFFFFF;
        }

        public BlockVertexData(BakedQuad quad, int vIndex)
        {
            this(quad.getVertices(), vIndex);
        }

        public BlockVertexData(int[] data, int vIndex)
        {
            vIndex *= 8;
            x = Float.intBitsToFloat(data[vIndex++]);
            y = Float.intBitsToFloat(data[vIndex++]);
            z = Float.intBitsToFloat(data[vIndex++]);
            color = data[vIndex++];
            u = Float.intBitsToFloat(data[vIndex++]);
            v = Float.intBitsToFloat(data[vIndex]);
        }

        public int[] toInts()
        {
            return new int[] {Float.floatToRawIntBits(x), Float.floatToRawIntBits(y), Float.floatToRawIntBits(z),
                color, Float.floatToRawIntBits(u), Float.floatToRawIntBits(v), 0, 0};
        }

        protected int[] toInts(TextureAtlasSprite texture)
        {
            return new int[] {
                Float.floatToRawIntBits(x), Float.floatToRawIntBits(y), Float.floatToRawIntBits(z),
                color,
                Float.floatToRawIntBits(texture.getU(u)), Float.floatToRawIntBits(texture.getV(v)),
                0, 0
            };
        }

    }

}
